package factory;

import java.sql.SQLOutput;

public class Order {
    Factory factory;
    int count;
    String[] models;
    int commonSum = 0; //общая сумма заказа
    Car[] cars;//Это фура под кол-во машин

    public Order(Factory factory, int count, String[] models) {
        this.factory = factory;
        this.count = count;
        this.models = models;
        cars = new Car[count];
        startOrder();
    }

    void showInfoOrder() {
        for (Car car : cars) {
            if (car != null) {
                System.out.println("Автомобиль " + car.titleCar + " стоит " + car.price);
            }
        }
        System.out.println("Общая стоимость заказа " + commonSum);
    }

    private void startOrder() {
        String modelCar;
        for (int i = 0; i < count; i++) {
            modelCar = models[(int) (Math.random() * models.length)];
            if (isExist(factory.listCars, modelCar)) {
                cars[i] = factory.createCar(modelCar);
                commonSum += cars[i].price;

            } else {
                System.out.println("Невозможно создать автомобиль.");
            }

        }
    }

    private boolean isExist(String[] arr, String a) {
        boolean result = false;
        for (String s : arr) {
            result = result || s.equals(a);
        }
        return result;
    }

}
