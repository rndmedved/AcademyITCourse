package factory;

public class Factory {
    String titleFactory;
    String[] listCars;

    Car createCar(String titleCar) {
        System.out.println("Завод приступил к постройке автомобиля.");
        return new Car(titleCar, (int) Math.round(Math.random() * 4000 + 1000));
    }

    public Factory(String titleFactory, String[] listCars) {
        this.titleFactory = titleFactory;
        this.listCars = listCars;
        System.out.println("Завод может изготовить следующие авто:");
        for (String car : listCars) {
            System.out.println(car);
        }
    }
}
