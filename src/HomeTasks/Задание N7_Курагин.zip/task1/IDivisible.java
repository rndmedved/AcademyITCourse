package lesson7.task1;

/**
 * Создал интерфейс, чтобы разнообразить выполнение программы.
 */
public interface IDivisible {
    void division();
}
