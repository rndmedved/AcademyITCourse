package lesson7.task1;

public class Main {
    public static void main(String[] args) {
        int[] arr1 = {10,2250,3,47,53,555,16,227,34,23,2,5};
        int[] arr2 = {2,3,0,5,6,0,8,11};
        new ArrDivision(arr1, arr2).division();
    }
}
