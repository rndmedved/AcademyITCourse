package ru.medved.chat.client;

import ru.medved.chat.client.resources.Tutorial;
import ru.medved.network.TCPConnection;
import ru.medved.network.TCPConnectionListener;

import javax.swing.*;
import javax.swing.text.DefaultCaret;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.IOException;

/**
 * Клиент, для подключения к серверу.
 * Данные клиент запускается в окне JFrame. Боле подробная информация описана там.
 */
public class ClientWindow extends JFrame implements TCPConnectionListener {
    private static String ipAddr = "127.0.0.1";
    private static int port = 8096;
    private static final int WIDTH = 600;
    private static final int HEIGHT = 400;
    private TCPConnection connection;
    private final JButton BUTTON = new JButton("Send");

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new ClientWindow();
            }
        });


    }

    private final JMenuBar jMenuBar = new JMenuBar();
    private final JMenu menu = new JMenu("menu");
    private final JTextArea log = new JTextArea();
    private final JTextField fieldNickName = new JTextField("Mikle");
    private final JTextField fieldInput = new JTextField(50);
    private final JPanel panelBottom = new JPanel();
    private final JScrollPane jScrollPane;

    private ClientWindow() {
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setSize(WIDTH, HEIGHT);
        setLocationRelativeTo(null);
        fieldNickName.setEditable(false);
        log.setEditable(false);
        log.setLineWrap(true);
        panelBottom.setLayout(new GridLayout());
//        fieldInput.setSize(50,300);
        add(panelBottom, BorderLayout.SOUTH);
        add(log, BorderLayout.CENTER);
        jScrollPane = new JScrollPane(log);
        add(jScrollPane);
        panelBottom.add(fieldInput, BorderLayout.CENTER);
        add(fieldNickName, BorderLayout.NORTH);
        BUTTON.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                sendMSG();
            }
        });
        fieldInput.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    sendMSG();
                }
            }
        });

        panelBottom.add(BUTTON, BorderLayout.SOUTH);
        setVisible(true);
        addJMenu(this);

    }

    private void addJMenu(ClientWindow clientWindow) {
        boolean isConnected = false;
        JMenu menu = new JMenu("menu");
        JMenu connect = new JMenu("Соединение");
        Font font = new Font("Arial", Font.BOLD, 15);
        JMenuItem item1 = new JMenuItem("Имя пользователя");
        JMenuItem item2 = new JMenuItem("О программе");
        JMenuItem item3 = new JMenuItem("Порт");
        JMenuItem item4 = new JMenuItem("IP адрес");
        JMenuItem item5 = new JMenuItem("Соединениться с сервером");
        JMenuItem item6 = new JMenuItem("Дисконнект");
        JMenuItem exit = new JMenuItem("Выход");
        item1.setFont(font);
        item2.setFont(font);
        item3.setFont(font);
        item4.setFont(font);
        item5.setFont(font);
        item6.setFont(font);
        exit.setFont(font);
        menu.add(item1);
        menu.add(item2);
        menu.addSeparator();
        menu.add(exit);
        connect.add(item3);
        connect.add(item4);
        connect.add(item5);
        connect.add(item6);
        item6.setEnabled(false);
        item1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                fieldNickName.setText(
                        JOptionPane.showInputDialog("Введите nick name участника чата"));
            }
        });
        item2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                new Tutorial().setVisible(true);
            }
        });
        item3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                port = Integer.parseInt(JOptionPane.showInputDialog("Введите новый порт"));
            }
        });
        item4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                ipAddr = JOptionPane.showInputDialog("Введите новый IP адрес в верном формате.");
            }
        });

        item5.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                try {
                    connection = new TCPConnection(clientWindow, ipAddr, port);
                    item5.setEnabled(false);
                    item6.setEnabled(true);
                } catch (IOException e) {
                    printMsg("Connection exception: " + e);
                }

            }
        });

        item6.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                connection.disconnect();
                item5.setEnabled(true);
                item6.setEnabled(false);

            }
        });


        exit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                System.exit(0);
            }
        });

        jMenuBar.add(menu);
        jMenuBar.add(connect);
        setJMenuBar(jMenuBar);
    }

    private void sendMSG() {
        String msg = fieldInput.getText();
        if (msg.equals("")) return;
        fieldInput.setText("");
        connection.sendString(fieldNickName.getText() + ": " + msg);
    }

    @Override
    public void onConnectionReady(TCPConnection tcpConnection) {
        printMsg("Connection ready...");
    }

    @Override
    public void onReceiveString(TCPConnection tcpConnection, String value) {
        printMsg(value);
    }

    @Override
    public void onDisconnect(TCPConnection tcpConnection) {
        printMsg("Connection close");
    }

    @Override
    public void onException(TCPConnection tcpConnection, Exception e) {
        printMsg("Connection exception: " + e);
    }

    private synchronized void printMsg(String msg) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                log.append(msg + "\n");
                DefaultCaret caret = (DefaultCaret) log.getCaret();
                caret.setUpdatePolicy(DefaultCaret.ALWAYS_UPDATE);
                log.setCaretPosition(log.getDocument().getLength());
            }
        });
    }
}
