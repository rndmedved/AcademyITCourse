package ru.medved.chat.client;

import ru.medved.network.TCPConnection;
import ru.medved.network.TCPConnectionListener;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * Клиент, для подключения к серверу. Весь диалог ведется в консоли.
 */
public class ClientConsole implements TCPConnectionListener {
    private static final String IP_ADDR = "192.168.1.118";
    private static final int PORT  = 8189;
    private static final BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
    private TCPConnection connection;

    ClientConsole(){
        try {
            connection = new TCPConnection(this,IP_ADDR, PORT);
            System.out.println("Введите имя пользователя.");
            String nickName = in.readLine();
            while (true) {
                System.out.print("сообщение: ");
                String msg = in.readLine();
                connection.sendString(nickName + ": " + msg);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    ClientConsole(String nickName){
        try {
            connection = new TCPConnection(this,IP_ADDR, PORT);
            while (true) {
                System.out.print("сообщение: ");
                String msg = in.readLine();
                connection.sendString(nickName + ": " + msg);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static void main(String[] args) {


            new Thread(new Runnable() {
                @Override
                public void run() {
                    System.out.println("Введите имя пользователя.");

                    try {
                        new ClientConsole(in.readLine());
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                }
            }).start();




    }

    @Override
    public void onConnectionReady(TCPConnection tcpConnection) {
        System.out.println("Connection ready...");
    }

    @Override
    public void onReceiveString(TCPConnection tcpConnection, String value) {
        System.out.println(value);
    }

    @Override
    public void onDisconnect(TCPConnection tcpConnection) {
        System.out.println("Connection close");
    }

    @Override
    public void onException(TCPConnection tcpConnection, Exception e) {
        System.err.println("Connection exception: " +e);
    }
}
