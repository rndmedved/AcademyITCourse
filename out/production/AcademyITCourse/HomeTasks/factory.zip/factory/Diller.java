package factory;

public class Diller {
    String titleDiller;
    int ageDiller;

    public Diller(String titleDiller, int ageDiller) {
        this.titleDiller = titleDiller;
        this.ageDiller = ageDiller;
    }

    void makeOrder(Factory factory, int count, String[] models) {
        Order order = new Order(factory, count, models);
        order.showInfoOrder();
    }
}
