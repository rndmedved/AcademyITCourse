package org.db;

import javax.xml.xpath.XPathExpressionException;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.*;
import java.util.Map;

public class Main {
    private Connection connection;
    private Statement statement;

    private Map<String, String> mapServer;
    private static final BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

    public Main() throws ClassNotFoundException, SQLException, XPathExpressionException, FileNotFoundException {
        mapServer = new ConfigConnection().getConnection();
            Class.forName(mapServer.get("driver"));
        String url = "jdbc:mysql://" + mapServer.get("URL") + "/" + mapServer.get("base");
        connection = DriverManager.getConnection(url,mapServer.get("login"),mapServer.get("password"));
//        Class.forName(Config.DRIVER);//зарегистрировали драйвер для работы с базой данных
//        String url = "jdbc:mysql://" + Config.SERVER + "/" + Config.DB;
//        connection = DriverManager.getConnection(url,Config.LOGIN,Config.PASSWORD);
//        С помощью объекта connection можно создать объект класса Statement с помощью которого
//                можно создавать запросы к базе данных
        statement = connection.createStatement();
    }
    int insertData(String title, int price, String info) throws SQLException {
        PreparedStatement preparedStatement = connection.prepareStatement(
                "INSERT INTO goods(title, price, info) VALUES (?, ?, ?)");
        preparedStatement.setString(1, title);
        preparedStatement.setInt(2,price);
        preparedStatement.setString(3,info);
        return preparedStatement.executeUpdate();
    }

    void showData(String table) throws SQLException {
        ResultSet rs = statement.executeQuery("select * from " + table);
        switch (table) {
            case "goods":
                while (rs.next()) {
                    System.out.printf("Автомобиль id %d марка %s стоит %d\n",
                            rs.getInt("id"),
                            rs.getString("title"),
                            rs.getInt("price"));
                }
            case "basket":
                while (rs.next()){
                    System.out.printf("В корзине находится товар, id которого %d, в количестве %d.\n",
                            rs.getInt("good_id"),
                            rs.getInt("count"));
                }
        }
        rs.close();
    }

    /**
     * В этом методе выполняется обновление стоимости авто
     * @param title
     * @param price
     * @return
     */
    int updatePrice(String title,int price) throws SQLException {
        PreparedStatement preparedStatement = connection.prepareStatement(
                "UPDATE goods SET price = ? where title = ?");
        preparedStatement.setInt(1,price);
        preparedStatement.setString(2,title);
        return preparedStatement.executeUpdate();

//        return statement.executeUpdate("UPDATE goods " +
//                "SET price = " + price + " WHERE title ='" + title + "'");
    }

    public static void main(String[] args) throws ClassNotFoundException, SQLException, IOException, XPathExpressionException {
        Main main = new Main();
        main.showData("goods");
        System.out.println("Введите id товара, который желаете добавить в корзину.");
        main.insertGoodInBasket(Integer.parseInt(reader.readLine()));
        main.showData("basket");
//        System.out.printf("Введите название авто и новую цену через пробел");
//        String info[] = (new BufferedReader(new InputStreamReader(System.in)).readLine()).split(" ");
//        main.updatePrice(info[0], Integer.parseInt(info[1]));
//        System.out.println("Информация о товарах после изменения стоимости");
//        main.insertData("lada", 2000, "smth");
//        main.showData("goods");
        main.statement.close();
        main.connection.close();

    }

    private int insertGoodInBasket(int goodId) throws SQLException {
        ResultSet resultSet = statement.executeQuery("select * from basket");
        PreparedStatement preparedStatement;
        while (resultSet.next()) {
            if (resultSet.getInt("good_id") == goodId) {
                preparedStatement = connection.prepareStatement(
                        "UPDATE `basket` SET `count` = `count` + 1");
                return preparedStatement.executeUpdate();
            }
        }
        preparedStatement = connection.prepareStatement(
                "INSERT INTO basket(good_id, count) VALUES (?, ?)");
        preparedStatement.setInt(1,goodId);
        preparedStatement.setInt(2,1);
        return preparedStatement.executeUpdate();
    }
}
