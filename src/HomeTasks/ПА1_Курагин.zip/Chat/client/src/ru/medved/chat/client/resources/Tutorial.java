package ru.medved.chat.client.resources;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Tutorial extends JFrame{

    JLabel textField = new JLabel("<HTML><h1 align = \"center\">Мини чат для своих.</h1>" +

            "<p align = \"center\">1) Чат разработан Курагиным Михаилом.<br>" +
            "в работе использовались материалы из YouTube канала GeekBrains<br>" +

            "В рамках итогового проекта по первой части обучения в Академии IT.<br>" +
            "Вы можете подключиться к серверу, выбрав IP адрес и порт подключения.<br>" +
            "По умолчанию стоит IP адрес: 127.0.0.1 и порт: 8096" +
            "Многие функции не реализованы, однако полноценный чат обещается сделать далее<br>" +
            "Главное есть возможность уже общаться друг с другом на любом расстоянии<br>" +
            "Как выяснилось. При наличии белого IP можно запускать сервер<br> и клиент и общаться по сети интернет.<br>" +
            "Я был удивлен таким поведением игрушечного проекта.<br>" +

            "Уадчного использования программы!<br>" +
            "С уважением, Курагин Михаил.</p>");
    JButton button;
    public Tutorial(){
        setSize(750, 400);
        setResizable(false);
        button = new JButton("Закрыть справку");
        textField.setFont(new Font("Arial", Font.ITALIC, 14));
        Container container = getContentPane();
        container.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 20));
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
            }
        });
        container.add(textField);
        container.add(button);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }
}
