public class Config {
    public static String DRIVER = "com.mysql.cj.jdbc.Driver";
    public static String SERVER = "localhost";
    public static String DB = "lesson16";
    public static String LOGIN = "root";
    public static String PASSWORD = "";
}
