package factory;

public class Car {
    String titleCar;
    int price;

    public Car(String titleCar, int price) {
        this.titleCar = titleCar;
        this.price = price;
    }
}
