package lesson8.carNumbers;

public enum Gender {
    MALE,
    FEMALE
}
