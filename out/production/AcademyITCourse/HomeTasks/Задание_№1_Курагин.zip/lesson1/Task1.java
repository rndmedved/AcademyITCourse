package lesson1;

import javax.swing.JOptionPane;

public class Task1 {
    public static void main(String[] args) {
        String text = "Silence\nis\ngolden";
        JOptionPane.showMessageDialog(null,text);
    }
}
