package org.db;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.HashMap;
import java.util.Map;

public class ConfigConnection {
    private static ConfigConnection object;
    private Map<String, String> connection;

    public ConfigConnection() throws XPathExpressionException, FileNotFoundException {
        var factory = XPathFactory.newInstance();
        var parser = factory.newXPath();
        var query = parser.compile("//server");
        connection = new HashMap<>();
        Node node = (Node) query.evaluate(new InputSource(
                new FileReader("./src/main/java/org/db/connection.xml")), XPathConstants.NODE);


        NodeList childList = node.getChildNodes();
        for (int j = 0; j < childList.getLength(); j++) {
            if (childList.item(j) instanceof Element) {
                connection.put(childList.item(j).getNodeName(), childList.item(j).getTextContent());
            }
        }

    }

    public Map<String, String> getConnection() {
        return connection;
    }


}
