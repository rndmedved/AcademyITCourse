package salary;

public abstract class Salary {
    final int BASE_RATE = 16242;
//    public abstract int baseRate();

    public abstract int getSalary();

}
